"use strict";

/* 대소문자 구분 */
var i = 10;
var I = 10; // 숫자, Number
/* 큰 따음표가 있는 경우는 문자.  */
var I = "10"; // 문자열, string
var I = true; // 불린 (있다, 없다) Boolean


